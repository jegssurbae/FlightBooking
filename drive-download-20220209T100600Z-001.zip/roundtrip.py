import tkinter as tk
from tkinter import ttk
from tkinter import *
from tkinter.filedialog import asksaveasfile

root = Tk()
root.title('Flight Booking')
root.geometry('500x450')

title = ttk.Label(root,
                  text='TRAVEL AIRLINES',
                  font=('Times New Roman', 25, 'bold'),
                  wraplength=500)
lbl = ttk.Label(root,
                text="ROUND TRIP FLIGHT",
                font=("Times new roman", 14),
                wraplength=500)
title.pack()
lbl.pack()


def save():
    name = nme.get()
    depart = dprt.get()
    rturn = rtrn.get()
    adult = a.get()
    children = c.get()
    infant = i.get()

    if nme != "":
        import error
    elif dprt != "":
        import error
    elif rtrn != "":
        import error
    elif a != "":
        import error
    elif c != "":
        import error
    elif i != "":
        import error

    f = open("21-1772.txt", 'w')
    f.write("^~~~~~~~~~~~~~~~~^" + '\n')
    f.write("GUI Round trip" + '\n')
    f.write("Name: "+ name + '\n')
    f.write("from: "+ depart + '\n')
    f.write("to: " + rturn + '\n')
    f.write("adult: " + adult + '\n')
    f.write("chldrn: " + children + '\n')
    f.write("infant: " + infant + '\n')
    f.close()


def dd(event):
    print('depart: ', event.widget.get())
    print('---')
    selected = event.widget.get()


def rr(event):
    print('return: ', event.widget.get())
    print('---')
    selected = event.widget.get()


def aa(event):
    print('Adult: ', event.widget.get())
    print('---')
    selected = event.widget.get()


def cc(event):
    print('Children: ', event.widget.get())
    print('---')
    selected = event.widget.get()


def ii(event):
    print('Infant: ', event.widget.get())
    print('---')
    selected = event.widget.get()


def back():
    root.destroy()
    import main


def error():
    import error


nme = Entry(root)
nme_label = Label(root, text='Name')
nme.pack()
nme_label.pack()


dprt = ttk.Combobox(root, text='Depart',values=["IloIlo", "Manila", "Cebu", "Pampanga", "Davao", "Aklan", "Bulacan"],
                    font=("Times new roman", 10))
dprt_bind = dprt.bind('<<ComboboxSelected>>', dd)
d = Label(root, text='Departure')
dprt.pack()
d.pack()


rtrn = ttk.Combobox(root, text='Return',values=["IloIlo", "Manila", "Cebu", "Pampanga", "Davao", "Aklan", "Bulacan"],
                    font=("Times new roman", 10))
rtrn_bind = rtrn.bind('<<ComboboxSelected>>', rr)
r = Label(root, text='Destination')
rtrn.pack()
r.pack()

space = Label(root, text='')
space.pack()
ps = Label(root, text='Number of Passengers')
ps.pack()

a = ttk.Combobox(root, text='Adults',values=['1', '2', '3', '4', '5', '6', '7', '8', '9', '10'], font=("Times new roman", 10))
a_bind = a.bind('<<ComboboxSelected>>', aa)
adlt = Label(root, text='Adults')
adlt.pack()
a.pack()

c = ttk.Combobox(root, text='Children',values=['0','1', '2', '3', '4', '5', '6', '7', '8', '9', '10'], font=("Times new roman", 10))
c_bind = c.bind('<<ComboboxSelected>>', cc)
chldrn = Label(root, text='Children')
chldrn.pack()
c.pack()

i = ttk.Combobox(root, text='Infant',values=['0','1', '2', '3', '4', '5', '6', '7', '8', '9', '10'], font=("Times new roman", 10))
i_bind = i.bind('<<ComboboxSelected>>', ii)
infnt = Label(root, text='Infant')
infnt.pack()
i.pack()

space = Label(root, text='')
space.pack()
btn = ttk.Button(root, text="save", command=lambda:save())
btn.pack()
space.pack()
btn1 = ttk.Button(root, text="back", command=back)
btn1.pack()

