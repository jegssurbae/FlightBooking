from tkinter import ttk
from tkinter import *


def ok():
    root.destroy()


root = Tk()
root.title('Flight Booking')
root.geometry('200x100')

space = Label(root, text='')

ps = Label(root, text='Please fill in all the blanks')
btn = ttk.Button(root, text='ok', command=ok)
space.pack()
ps.pack()
btn.pack()