def name():
    print("^~~~~~~~~~~~~~~~~^")
    name = input(f"Enter the name of the Account : ")
    print("Welcome! " + name + " let's help you book a flight.")
    f = open(f"21-1772.txt", "a")
    f.write("^~~~~~~~~~~~~~~~~^"+"\n")
    f.write("nme: " + name + "\n")


def round():
    while True:
        print("^~~~~~~~~~~~~~~~~^")
        print("~~~^Round Trip Flight^~~~")
        print("- Manila", "- IloIlo", "- Cebu", "- Pampanga", "- Davao", "- Aklan", "- Bulacan", sep='\n')
        depart = input(f"Where are you from? ")
        arrival = input(f"Where are you headed to? ")
        print("^~~~~~~~~~~~~~~~~^")
        print("No. of passengers: ")
        adlt = input("Adults: ")
        chldrn = input("Children: ")
        infnt = input("Infant: ")
        f = open(f"21-1772.txt", "a")
        print()
        print("~~~^Round Trip Flight^~~~")
        print("Your flight is a Round Trip flight, We will be there you until your returning flight")
        print("Departing flight ", "From: " + depart, " To: " + arrival, sep='\n')
        print("Returning flight ", "From: " + arrival, " To: " + depart, sep='\n')
        print("^~~~~~~~~~~~~~~~~^")
        print("No. of passengers: ")
        print("Adults: " + adlt)
        print("Children: " + chldrn)
        print("Infant: " + infnt)
        print()
        print("Thank you")

        if depart == 'manila':
            f.write("frm: " + depart + "\n")
        elif depart == 'iloilo':
            f.write("frm: " + depart + "\n")
        elif depart == 'cebu':
            f.write("frm: " + depart + "\n")
        elif depart == 'pampanga':
            f.write("frm: " + depart + "\n")
        elif depart == 'davao':
            f.write("frm: " + depart + "\n")
        elif depart == 'aklan':
            f.write("frm: " + depart + "\n")
        elif depart == 'bulacan':
            f.write("frm: " + depart + "\n")
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")

        if arrival == 'manila' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'iloilo' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'cebu' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'pampanga' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'davao' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'aklan' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'bulacan' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")
                exit()
            else:
                print("Invalid Input")
                exit()


def oneway():
    while True:
        print("^~~~~~~~~~~~~~~~~^")
        print("~~~^One-Way Trip Flight^~~~")
        print("- Manila", "- IloIlo", "- Cebu", "- Pampanga", "- Davao", "- Aklan", "- Bulacan", sep='\n')
        depart = input(f"Where are you from? ")
        arrival = input(f"Where are you headed to? ")
        print("^~~~~~~~~~~~~~~~~^")
        print("No. of passengers: ")
        adlt = input("Adults: ")
        chldrn = input("Children: ")
        infnt = input("Infant: ")
        f = open(f"21-1772.txt", "a")
        print()
        print("~~~^One-Way Trip Flight^~~~")
        print("Your flight is a Oneway Trip flight, Please Let us know if you want to re-book a flight")
        print("Departing flight: ", "From: " + depart, " To: " + arrival, sep='\n')
        print("^~~~~~~~~~~~~~~~~^")
        print("No. of passengers: ")
        print("Adults: " + adlt)
        print("Children: " + chldrn)
        print("Infant: " + infnt)
        print()
        print("Thank you")

        if depart == 'manila':
            f.write("frm: " + depart + "\n")
        elif depart == 'iloilo':
            f.write("frm: " + depart + "\n")
        elif depart == 'cebu':
            f.write("frm: " + depart + "\n")
        elif depart == 'pampanga':
            f.write("frm: " + depart + "\n")
        elif depart == 'davao':
            f.write("frm: " + depart + "\n")
        elif depart == 'aklan':
            f.write("frm: " + depart + "\n")
        elif depart == 'bulacan':
            f.write("frm: " + depart + "\n")
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")

        if arrival == 'manila' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'iloilo' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'cebu' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'pampanga' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'davao' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'aklan' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival == 'bulacan' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")
                exit()
            else:
                print("Invalid Input")


def multi():
    while True:
        print("^~~~~~~~~~~~~~~~~^")
        print("~~~^Multi City Trip Flight^~~~")
        print("- Manila", "- IloIlo", "- Cebu", "- Pampanga", "- Davao", "- Aklan", "- Bulacan", sep='\n')
        depart = input(f"Where are you from? ")
        arrival = input(f"Where are you headed to? ")
        arrival2 = input(f"Where is the second destination? ")
        print("^~~~~~~~~~~~~~~~~^")
        print("No. of passengers: ")
        adlt = input("Adults: ")
        chldrn = input("Children: ")
        infnt = input("Infant: ")
        print()
        print("~~~^Multi City Trip Flight^~~~")
        print("Your flight is a Multi City Trip flight, We will be there you until your second departure and "
              "returning flight")
        print("- Departing flight: ", "From: " + depart, " To: " + arrival, sep='\n')
        print("- Second Departing flight: ", "From: " + arrival, " To: " + arrival2, sep='\n')
        print("- Returning flight: ", "From: " + arrival2, " To: " + depart, sep='\n')
        print("^~~~~~~~~~~~~~~~~^")
        print("No. of passengers: ")
        print("Adults: " + adlt)
        print("Children: " + chldrn)
        print("Infant: " + infnt)
        print()
        print("Thank you")
        f = open(f"21-1772.txt", "a")

        if depart == 'manila':
            f.write("frm: " + depart + "\n")
        elif depart == 'iloilo':
            f.write("frm: " + depart + "\n")
        elif depart == 'cebu':
            f.write("frm: " + depart + "\n")
        elif depart == 'pampanga':
            f.write("frm: " + depart + "\n")
        elif depart == 'davao':
            f.write("frm: " + depart + "\n")
        elif depart == 'aklan':
            f.write("frm: " + depart + "\n")
        elif depart == 'bulacan':
            f.write("frm: " + depart + "\n")
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")

        if arrival == 'manila':
            f.write("to: " + arrival + "\n")
        elif arrival == 'iloilo':
            f.write("to: " + arrival + "\n")
        elif arrival == 'cebu':
            f.write("to: " + arrival + "\n")
        elif arrival == 'pampanga':
            f.write("to: " + arrival + "\n")
        elif arrival == 'davao':
            f.write("to: " + arrival + "\n")
        elif arrival == 'aklan':
            f.write("to: " + arrival + "\n")
        elif arrival == 'bulacan':
            f.write("to: " + arrival + "\n")
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")

        if arrival2 == 'manila' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival2 == 'iloilo' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival2 == 'cebu' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival2 == 'pampanga' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival2 == 'davao' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival2 == 'aklan' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        elif arrival2 == 'bulacan' and adlt.isdigit() and chldrn.isdigit() and infnt.isdigit():
            f.write("to: " + arrival2 + "\n")
            f.write("No. of pssngrs" + '\n')
            f.write("Adlts: " + adlt + '\n')
            f.write("chldrn: " + chldrn + '\n')
            f.write("infnt: " + infnt + '\n')
            f.close()
            break
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again? [y/n]: ")
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")
                exit()
            else:
                print("Invalid Input")
                exit()


def trip():
    while True:
        print("[1] Round Trip", "[2] One-Way Trip", "[3] Multi City trip", sep="\n")
        trip_m = input("Your flight: ")
        f = open(f"21-1772.txt", "a")
        f.write("flht: " + trip_m + '\n')
        if trip_m == '1':
            round()
            break
        elif trip_m == '2':
            oneway()
            break
        elif trip_m == '3':
            multi()
            break
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again?[y/n]: ")
            print()
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")
                exit()
            else:
                print("Invalid Input")
                exit()

def home():
    while True:
        print("~~~^FLIGHT BOOKING^~~~")
        ques = input("Do you want to continue with console or in GUI? ")
        if ques == 'GUI':
            import main
        elif ques == 'console':
            name()
            trip()
            break
        else:
            print("Invalid Input, Please try again with the given keyword")
            again = input("Would you like to try again?[y/n]: ")
            print()
            if again == 'y':
                continue
            elif again == 'n':
                print("Okay, Thank you for using our service! Please let us know if you still need our help.")
                exit()
            else:
                print("Invalid Input")
                exit()


home()
