from tkinter import ttk
from tkinter import *

root = Tk()
root.title('Flight Booking')
root.geometry('500x300')

title = ttk.Label(root,
                  text='TRAVEL AIRLINES',
                  font=('Times New Roman', 25, 'bold'),
                  wraplength=500)
lbl = ttk.Label(root,
                text="FLIGHT BOOKING",
                font=("Times new roman", 14),
                wraplength=500)
title.pack()
lbl.pack()


def oneway():
    root.destroy()
    import oneway


def roundtrip():
    root.destroy()
    import roundtrip


def multi():
    root.destroy()
    import multi


def button():
        space = Label(root, text='')
        space.pack()
        btn = ttk.Button(root, text="One-way Flight", command=oneway)
        btn.pack()
        space = Label(root, text='')
        space.pack()
        btn = ttk.Button(root, text="Round Trip Flight", command=roundtrip)
        btn.pack()
        space = Label(root, text='')
        space.pack()
        btn = ttk.Button(root, text="Multi City Flight", command=multi)
        btn.pack()


button()
root.mainloop()
